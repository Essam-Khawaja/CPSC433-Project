CPSC 433 condensed proposal -- 22-page compiled draft

HOW TO USE
1. Back up the team's existing LaTeX repository or create a new Git branch.
2. Replace main.tex and the correspondingly named files in sections/ with those in this folder.
3. Compile main.tex twice with pdflatex (the PDF is included separately for preview).
4. Compare the original draft and revised source with EDIT_NOTES.txt before accepting changes.

STRUCTURE
- Two alternatives: OR feasibility -> Set-Based improvement; OR feasibility -> AND-Tree optimization.
- The two branches do NOT execute sequentially.
- The cover retains placeholders for members 2-5 and the submission date.
- The TOC and empty appendices are removed from main.tex to save pages.
- The original formal problem/constraint section is substantially preserved.

IMPORTANT REVIEW ITEMS
- The OR-tree section, abstract, intro, discussion and conclusion contain NEW text to complete the missing sections. Obtain team approval for that material.
- The edited set-based worked example is a different small instance from the AND-tree example; this is explicit in the integration discussion. The OR-tree worked example uses the AND-tree instance.
- The course assignment document requests two search paradigms; this proposal retains the team's intended shared OR + two optimization branches and merits instructor approval.
- The proposal is a reviewed draft, not a guaranteed grading or full mathematical verification of every interpretation.
